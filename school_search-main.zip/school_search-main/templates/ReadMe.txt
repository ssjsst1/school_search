Read Me....
Project Structure like below digram

1)school_Search_project/
   ├──main.py
   ├──templates/
      ├── index.html
      └── schoollist.html



2)
After adding the project run the below commands for install the required libraries
pip install requests
pip install BeautifulSoup4
pip install flask


